
package animacion;


public class Main {
      
    public static void main(String[] args) {
        // TODO code application logic here
        form1 f = new form1();
        f.show();
    }
}
